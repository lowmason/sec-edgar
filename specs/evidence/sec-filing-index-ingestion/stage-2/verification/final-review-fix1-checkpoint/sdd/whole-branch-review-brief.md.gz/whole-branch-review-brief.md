You are the fresh senior whole-branch reviewer for approved Stage2 acquisition. Routing MUST be gpt-6.1-sol with max effort and fresh context. You are read-only: no checkout/index/HEAD/worktree mutation, no nested agents. Review the complete Stage2 implementation against plan/spec and quality; this is the final whole-branch review, not another Task8-scoped review.

WHAT WAS IMPLEMENTED
Single Python>=3.14 distribution/CLI sec-edgar-ingest; strict immutable configuration/run/workset/result codecs; durable local SQLite/content object stores and scripted Azure Blob/Table adapters; one owner-wide leased Blob sentinel downloader coordination, daily priority and safe cancellation/takeover; bounded HTTP child lifecycle and original-byte envelope validation; failed-directory aware discovery and immutable SourceWorkset; raw promotion, write-once member binding, SnapshotWorkset and crash repair; discover/collect CLI, durable results and retained proof. Tasks1–8 executed with TDD/full+scoped Spec/Quality reviews. No ETL row parser, publication, orchestration or Stage3.

REQUIREMENTS
Read the entire approved plan specs/plans/2-sec-filing-index-ingestion-stage-2-spec.md and implementing spec specs/sec-filing-index-ingestion-stage-2-spec.md. Parent specs/sec-filing-index-ingestion-spec.md and ADR specs/sec-filing-index-ingestion-adr.md remain authority. Accepted F1 specs/sec-filing-index-ingestion-stage-1-findings.md final acceptance; inspect relevant contracts rather than capture-time pending text. Accepted F1 SHA939a724eccf22147015a59d5940ed57f02cc4e9fe9d942a9cd78ae73c34615ff and accepted manifest SHA124e96041548daba8216aa495fc69021751555b0f0e4c890ac85e934f512a131. All1584records checked at preflight. The untracked roadmap is a read-only local input.

GIT RANGE / INPUTS
Actual BASE, HEAD, full standard package and exact same-range authored review view will be supplied in dispatch. Read the authored view once in bounded complete passes; all runtime/tests/build/config/lock/docs and verification drivers are included. Full standard diff contains all immutable proof payloads as well: its omitted authored-view payloads are reviewed via manifest/maps/receipts rather than printing thousands of files; proof obligations are not waived. Do not rerun git diff when provided package suffices. Use revision reads for concrete ambiguities. Verify exact-view path/range coverage and package metadata. Review is frozen until your response.

SDD INPUTS
.sdd/2-sec-filing-index-ingestion-stage-2-spec/progress.md and minor-ledger.md;
task-{1..8}-report.md;
task-{1..8}-review.md plus task-{2..7}-rereview1.md;
task-8-fix1-rereview.md, task-8-fix2-rereview.md, task-8-i1-rereview.md.
Use full files at stated paths if output truncated. Each report records actual typed shared interfaces; earlier pre-fix reports are historical. Original Task8 operative full review retained a faithful descriptive condensation rather than falsely claiming literal full transcript, with original offline guard probe; all scoped responses retained complete. Current ledger composes their closures, not erases earlier FAIL.

PROOF / CURRENT CHECK
specs/evidence/sec-filing-index-ingestion/stage-2/verification.md and verification/evidence-inventory.json plus each append-only checkpoint inventory/manifests/maps:
original; task-8-fix1-checkpoint; task-8-fix2-checkpoint; task-8-controller-review-checkpoint; task-8-i1-checkpoint; newest controller acceptance checkpoint supplied by dispatcher.
Current complete check after LAST implementation: .sdd/task-8-fix2-final-check.txt =289 tests/107.544s, build/help/version/compile/CRLF-whitespace all0, 313lines48750B SHA f8d4af430fadfec27aea03ef51e936f94652c8defd82b8c9ab9c5ca433a8809c. Retained controller-task8-fix2-check-inspection.json independently scans each actual record/footer/noise.
Build/wheel sdist and installed proof verification/sec-edgar-wheel-1k5klfr3: actual20pin versions/site-packages import/all11 installed command receipts/equal18productionmembers. Wheel77862B SHAaabf437bdbf8ba521eab027112377372e4515026f0e153016557cc6829502628; sdist66284B SHA7fe7003fb193a55c68666a16de34e145c1ccf88fc18e1e05a7f48e77f5d53780. No production or build-input change after fix1; independently proven reuse at fix2/I1/currentacceptance.
Current real-process proof: 3collectorPIDs/3conditional inserts/1winner/2AlreadyExists; parentSIGTERM-15/successors0 after actualsocket drain and persistedunsafe84; daily queued work getsnextturn; min actual wire spacing.678s; fatal exchangechild-14; stale0. Earlier distinct RED .1194s actualwire spacing → durable completion floor corrected, GREEN.4678s, not hidden.
Actual7durable collection crash points/newcontext/noHTTP; retry-prefix quarantine beforeeachcrash with oldspool removed; actual2inserts1conflict/winner adoption; two-source recovery unresolvedonly. CLI4result/finish crashes: immutable result precedes finish and repairs exact Attempt without refetch.
I1 combined approved sequence verification/sec-edgar-stage-2-k8g11etz: 11actualcommands including literal2refusals; quarterlydiscover/collect/reuse/exactreplay; daily discover/incomplete3/exactreplay3/recovery0/finalreuse0. Actual owner Yes to separate daily end=open/quarterly2015Q1; receipt authoredtimeunknown. Dailyinitialdown1/pending1/failed1/noSnapshot; recoverydown1/unchanged1/finaldown0unchanged2. SQLite7Attempts/3Bindings/11TransportAttempts/10cursors;404→200onlydelayedday, eachcompletedbodyfetchedonce; codecs/raw/Bindings/current-vs-originctxverified. All96combinedpayloads/119checkpointpayloads/16maps and12015previous records/controls verified.
Do not regenerate suites/build/install/sequence merely to replace retained evidence. Read complete existing logs/receipts. A concrete unresolved risk may justify a bounded offline/local temporary probe with exact command/results; no live SEC/Azure/compute/auth/provider operations. Use .venv/bin/python (no python alias) and PYTHONPATH for no-write module reads; testguard closes network/resolution/auth; if doing a stub probe label actual limits. For no-write cache use PYTHONDONTWRITEBYTECODE=1. No rerun of full process suite unless retained evidence invalidated by concrete source change.

DEVIATIONS / SCOPE TO ASSESS
- Azure journal write+lease release not atomic: full unsafe_guard retained on clean release, local atomic release can shorten. Conservative throughput tradeoff explicit in runbook; newturn waits, no manual break. TimeBounds upper observations anchored same monotonic instant.
- Permit.next_allowed_at historical reservation value stays immutable; Turn.complete adds actual verified drain UTCupper+1/rate before release to bound real wire starts through adapter/DNS/TLS latency.
- Shared APIs expanded minimally: RunContext effective_config/pinned_on; acquisition_mode defaultreuse; strict origin receipt validator; stage_receipt optional keyword request_id whose omission failsclosed, actual production identity only; state runhalts/policy blocks retained. Actual signatures in reports.
- Unrepresentable valid RetryAfter failclosed durable owner-wide policy_block, no cap/automatic expiry/newrun escape; original receipt/rawheaders retained.
- Fixtureliteralabsolute configuredroot refusal fixed by relativeconfiguredroot+explicit--state-dir and explicit override markerflags. Owner supplied separate daily endpoint answer. Production pin/hash/guards unchanged.
- LocalMACarm64Py3.14.0 distinct from accepted Linuxamd64Py3.14.8; sixnativewheelbytesdiffer, twenty exact packageversionsmatch. Bounded/acceleratedlocalfixtures do not prove default90secLinux/Azureworkerfit.
- Named task-reviewer unavailable: fresh default read-only sameGPT6.1/rubric fallback documented. Whole-branch model remains exactrequired.
- Stage2stamp/tick/planstepmarkup/retirement/integration intentionally pending this technical review, then gated completion follows. Review cannot waive failedexits. All22S7effectiveAzure/worker checks reserved, retainedscaffolds excluded, four original index-ingest unstaged deletions preserved; primarylocal/untrackedroadmap preserved. No liveauthority and noStage3.
- CodexCLI second-opinion seat skipped because executorCodex samefamily (explicit skillrule), requiredyoustillruns.

REQUIRED CONTRACT COVERAGE
Assess whole producer-consumer acquisition pipeline: oneissuer/budget ALLrequests, durablepacing/retry/cooldown/policyhalt/dailypriority, lease loss/timeuncertainty/stale dispatch/inflightcancel+drain/successortakeover; failedlisting !=empty/404pending/openend/revisitolder/contiguousboundary; immutableRunContext/config/provenance/source/snapshotpinidentities and canonical paths; strict receipt identity/quarantine/originalbytes/envelopes/limits; Blob/Table create/CAS and no cross-store transaction; raw-beforeSnapshot-beforebinding/result-beforeAttempt-finish recovery; installedCLI/build/returncodes/networkguard/error semantics; protection/scope/evidencehonesty.
Do not claim unobserved live Azure behavior. State any Cannot verify dependency explicitly, without conflating missing a read with absent evidence.

OUTPUT use requesting-code-review template: Strengths; Issues Critical/Important/Minor each file:line, concrete defect/why/remediation; Recommendations; Assessment Ready to merge Yes/No/Withfixes and reasoning. State explicit whole-branch Spec/Quality verdict, exact BASE/HEAD/model/effort/scope and which acquisitioncontracts inspected. Report actual probes, corrected inspector assumptions and evidence limits. No findings means say each severity none. If interrupted, preserve completedcoverage and remainingcoverage; don't claim a completed gate. No code edits, nestedagents or completionmarkup.

GLOBAL CONSTRAINTS VERBATIM
## Global Constraints

The quoted contract sentences below are copied verbatim from the parent or ADR; numeric settings remain the accepted starting values. Every task includes these constraints.

- “The implementation will live in **`packages/sec-edgar-ingest/`**, with `sec-edgar-ingest` as the distribution and CLI name and `sec_edgar_ingest` as the Python import package.” (ADR Decision.)
- “All application requests to the SEC share one downloader and one request budget. More ETL workers must not mean more SEC traffic.” (Parent R8.)
- “Discovery requests, downloads, retries and reconciliation all count.” (Parent §4.3.)
- “All collectors in the owner's deployment use the same coordination namespace, including backfill and daily runs.” (Parent §4.3.)
- “Lease loss stops new requests. A successor waits for the previous ownership window and bounded in-flight request allowance to expire before issuing requests.” (Parent §4.3.)
- “Daily work gets the next turn ahead of remaining backfill or reconciliation units.” (Parent §4.3.)
- “Discovery writes an immutable source workset. Collection pins one accepted snapshot per member in the manifest, then emits a separate immutable snapshot workset naming exact hashes. Retries complete unresolved members without replacing pinned inputs. ETL never silently follows a mutable “latest”.” (Parent §4.1.)
- “Never advance discovery past a failed directory read.” (Parent §4.2.)
- “Also revisit pending and failed source identities regardless of their quarter.” (Parent §4.2.)
- “Daily discovery starts at the approved handoff date and replays overlap with the baseline.” (Parent §4.2.)
- “A truncated or invalid body is quarantined, never accepted as an empty index.” (Parent §4.3.)
- “Promote a valid download to its content-addressed raw location before marking it downloaded.” (Parent §4.3.)
- “Discovery may exist before a snapshot; failures belong to attempts and do not erase an earlier successful state.” (Parent §4.5.)
- “There is no assumed transaction spanning Blob Storage and Table Storage.” (Parent §4.6.)
- “An HTTP failure, absent listing or open-quarter absence is not a withdrawal.” (Parent R10.)
- “CI runs on committed fixtures and mocked SEC responses; it downloads nothing from the SEC.” (Parent §6.)
- Python >=3.14; intended historical range 2010 Q1 through the open quarter; initial development range 2015 Q1 through the open quarter; resolve and pin the end quarter at each run's start; daily handoff 2026-10-01; SEC User-Agent `Lowell Mason sec-edgar-ingest mason.lowell@mac.com`.
- `sec.requests_per_second`: 3 requests/second, no bursts; `sec.max_active_collectors`: 1 across all application pipelines; `http.max_attempts`: 5 total per request, including the first.
- `http.retry_base_seconds`: 2; `http.retry_cap_seconds`: 120; exponential with jitter, honor longer server delays; `http.connect_timeout_seconds`: 15; `http.read_timeout_seconds`: 60.
- `jobs.replica_retry_limit`: 0; `orchestration.transient_replays`: at most 1 for positively confirmed transient failure; no automatic replay of an ambiguous start. No scheduler/job implementation here.
- Versions are required, explicit and pinned per workset: `etl.parser_version`, `etl.schema_version`, `worker.image_digest`; canonical schema remains `sec-index-v1`. Stage 2 does not implement a parser.
- Accepted acquisition guards, owner answer 2026-10-06: 90 seconds per complete HTTP exchange; 67,108,864 received bytes; 536,870,912 expanded IDX bytes. Guard violations retain evidence and leave unresolved work. No recovery-horizon, format-coverage or capacity claim follows from these values.
- Keep client/download scaffolds on disk but excluded from the workspace and runtime dependency graph. Preserve the four original index-ingest deletions without staging them. Preserve the local/untracked roadmap; never include it incidentally in a commit/PR.
- Accepted F1 remains immutable at SHA-256 `939a724eccf22147015a59d5940ed57f02cc4e9fe9d942a9cd78ae73c34615ff`; accepted evidence manifest is `124e96041548daba8216aa495fc69021751555b0f0e4c890ac85e934f512a131`. Historical pending text is superseded by final acceptance and completion records.
- Quarterly ZIP with one DEFLATE `master.idx` and plain daily IDX are the selected acquisition representations. Bounded specimens are not global format coverage. The 33 uninspected historical daily directories establish no recovery horizon or ingestion coverage.
- Planning and ordinary tests use retained evidence/offline inspection. Stage 1 SEC and temporary compute windows are closed. Fresh live SEC/Azure/compute work needs concrete new authorization and one owner-wide issuer/budget. Delegating code never authorizes network work.
- Do not implement or plan row parsing/normalization, generation publication, reconciliation/withdrawal approval, Azure orchestration/provisioning or scheduled activation. Preserve their parent contracts and stage boundaries.
- Final whole-branch reviewer is explicitly `gpt-6.1-sol`, reasoning effort `max` (GPT-6.1 Max), fresh context and read-only. This owner instruction supersedes generic Opus routing. If unavailable, report the gate as unpassed; do not substitute silently.

