Fresh GPT-6.1 Max SCOPED re-review of final whole-branch fix round1. Read-only on checkout/source/index/HEAD, no nested agents, no live SEC/Azure/auth/compute. Previous full whole-branch review at9098fe9 is complete; check ONLY its findings below and defects introduced by these fixes. Read complete authored fix view once in bounded passes plus exact full-standard package supplied at dispatch. Evidence payload omissions assessed via manifest/maps/receipts, not waived. Use report .sdd/2-sec-filing-index-ingestion-stage-2-spec/final-review-fix1-report.md and original fullverdict whole-branch-review-9098fe9.md if more context needed. Actual BASE9098fe9b664d9f44a663fdd8357e34030c37e932..HEAD and paths/hashes supplied after checkpointfreeze.

Requirements: approved Plan2 GlobalConstraints copied verbatim below, preservingparent/ADR/F1 ranges/identity/oneissuer/statecontracts and all22S7reserved. Minimumcompatible AzureStateStore optionalkeyword objects uses existing sharedAzureObjectStore, no clients/resources/config/pins/budget/SourceWorkset/Snapshot IDs changed. Small legacy Payload inline; oversized content-first immutable envelope with identity/hash/length and small versioned Tabledescriptor; complete logicalrecord actualTableETagCAS. Evaluate property/entitybounds includingkeys, descriptor/envelopeversion/type/hash/path/namespace/kind/key/canonicalcontent validation, missing/corrupt/mismatchedobject handling, priorinlinecompatibility, partialcandidate/CASloser preservation and source/attempt readscan semantics. Strict producer/decoder sharedvalidation mustbindsource SourceID/canonicalURL/representation/exactrawperiod+path/envelope and validDirectorymembership. Historicaldailyfixturedaylabels normalizedonlytoquarter; eachactualrawday/SourceIDstillchecked, existingvalidbytes/IDsunchanged. Operative runbook actualYes/two-configapprovedproof links corrected; historicalreports notrewritten.

Introduced test-only midnightfix: real_context originallyupdatedstarted_at to actualUTC butretainedfixed2026-10-06pin; crossingUTCmidnight legitimatelyrefused override beforeAttempt,threechildrenexit1/noAttempts/queue.Empty. Exact initial302predecessor301fullfailure and diagnostictrace retained. New deterministicdate-independent regression thenhelpercarry sameactualnow.date(), productionguards/timeouts/config unchanged; five processcasesGREEN and latestcomplete full302/tests106.619s/checkwrapper106.996s all0. Evaluatehelperfix&regression onlyasintroduceddefectscope, not broadercoordinatorrereview.

Current latestprescribedfullcheck AFTERLASTimplementation includes actual302records/build/help/version/compile/CRLFwhitespace, freshinstalledwheelproof sec-edgar-wheel-n0zc5qlc79files489607B,20pins11commands4transports; wheel79085B SHA349b9524fca4963de4a2ffdf3fb96f28708c01dba49564594a92944cc3ee5d28; sdist67566B SHAfce247b48d02155eed403ff0456f5e5bc246cde244534e6eb428c9a44d361b30.
Freshapprovedcombined sec-edgar-stage-2-46bhxh8j97files502536B96records/all11exit2/0/0/0/0/2/0/3/3/0/0. Independentfreshproofinspection old4worksets byte/IDvalidity,19wheel/sdistsources,27unchangedSDKhashes,raw/Bindings/currentvsoriginctx/SQLitematches; latestprocess3PIDs50088/89/90 1winner2conflicts85guardobservations minspacing.682671625s timer-14 all14crash/7prefix/4result/7guard. ActualfixtureSourceContext differences produce83,022UTF16B historicalboundary versusoriginalreview82334, notincorrectclaimedidenticalinput. Offlineadapter layout proof Tablebounds maxentity24786/maxString23360, winnerpreserved/neworphanverified.
Use actualreport/proofmanifest for all exactlog hashes/argv/date/footer/limits/newsourcehashes. Source/docs/proof frozenaftercheckpoint. Do not regenerate suites/build/install/sequence to replace retainedevidence. A concrete introducedrisk canjustifyboundedguardedoffline/tmp/stubprobe; exactcmd/outputscope required. .venv/bin/python and PYTHONDONTWRITEBYTECODE=1; testguardbeforeimports; no providerclient/credential/live/network outside explicitlyselectedlocalfixture. No alternativecodexCLIseat samefamily.

Output per-finding ADDRESSED/NOTADDRESSED with exacthunks/pathlines, then NEW Critical/Important/Minorfindings. State exactBASE/HEAD/modelmax/default-rolefallback, evidencechecked/limits/probesandcorrectedinspectionassumptions. No fullbranchauditrepeat. Ifcleanthisscope closesfullwholebranch originalSpec/Qualityfail; controller composesverdict andrunscompletion. Stamp/tick/retirement notyeteligible and all22S7stillreserved. Save complete final scopedverdict/report verbatim UTF8 outsidecheckout to /private/tmp/sec-edgar-stage2-final-fix1-rereview.md solelyasauthorizedreportartifact, thenreturnpointer/hashandfullfindingverdicts. Report artifactwrite is allowed; nocheckout/source edits.

PREVIOUS FINDINGS VERBATIM


**Critical — none.**

**Important**

1. **[P2] A supported historical discovery cannot fit Azure’s single string payload.**

   File: [azure.py:68](/Users/lowell/.codex/worktrees/sec-edgar-stage-2/sec-edgar/packages/sec-edgar-ingest/src/sec_edgar_ingest/storage/azure.py:68). The affected state construction is [state.py:94](/Users/lowell/.codex/worktrees/sec-edgar-stage-2/sec-edgar/packages/sec-edgar-ingest/src/sec_edgar_ingest/state.py:94).

   `_entity()` puts the entire canonical state value into one `Payload` string. `begin_discovery()` first registers every unresolved required directory in the single `DiscoveryBoundary/daily` row.

   With the accepted intended range **2010Q1 through the pinned open quarter 2026Q4**, the real inventory produces 86 directory units. Running that registration in memory and passing the resulting value through the actual Azure serializer produces a **41,167-character / 82,334-byte UTF-16LE string**. This exceeds Azure Table Storage’s 64 KiB string-property limit. It fails while registering discovery, before any SEC request can resolve the pending gaps.

   The initial development range, 2015Q1–2026Q4, produces 58,404 UTF-16LE bytes and fits. That explains why the retained small fixture and development-range checks do not expose the intended-history failure. This is an adapter representability defect in an accepted configuration; the reserved Stage 7 capacity proof does not make it acceptable.

   **Fix:** Give Azure state a representation that respects both property and entity limits while preserving the conditional update of the complete boundary. Add an offline adapter regression using the actual 2010Q1 inventory and registration value, covering encode/decode and conditional replacement. Retain the accepted historical range and the shared boundary semantics.

   This finding comes from a guarded in-memory size probe and source inspection. I did not construct an Azure client or claim an observed service rejection.

2. **[P2] Snapshot decoding omits the exact source-period validation performed by its producer.**

   File: [worksets.py:131](/Users/lowell/.codex/worktrees/sec-edgar-stage-2/sec-edgar/packages/sec-edgar-ingest/src/sec_edgar_ingest/worksets.py:131). Compare the stronger producer check at [worksets.py:157](/Users/lowell/.codex/worktrees/sec-edgar-stage-2/sec-edgar/packages/sec-edgar-ingest/src/sec_edgar_ingest/worksets.py:157).

   `_validate_snapshot()` checks source membership and representation, but does not verify that a snapshot’s raw address belongs to that exact source period. `make_snapshot_workset()` does verify the exact address, period and envelope.

   Starting with a valid quarterly snapshot workset, I changed only `raw_path` from `period=2015Q1` to `period=2015Q2`, recomputed the workset’s canonical digest, and decoded it through `decode_snapshot_workset()`. The decoder accepted it while the directory still named **2015Q1** and the snapshot retained the **2015Q1 SourceID**.

   The producer currently prevents this combination during normal collection. The defect is at the strict persisted/public decoding boundary: a well-formed, correctly hashed workset can claim a different quarter’s raw object for its named source. A digest validates the supplied content, so it does not replace semantic source validation.

   **Fix:** Apply equivalent exact source-address and period validation during decoding, including agreement with directory membership and the SourceID. Share the semantic validation with the producer, or supply an explicitly validated source workset if that is necessary to establish the exact member. Add a rejection test for a wrong-period raw path with a valid recomputed workset digest.

**Minor**

1. **[P3] The current runbook still describes the approved two-config sequence as awaiting an owner decision.**

   File: [sec-edgar-ingest-acquisition.md:115](/Users/lowell/.codex/worktrees/sec-edgar-stage-2/sec-edgar/docs/runbooks/sec-edgar-ingest-acquisition.md:115).

   Lines 115–117 say the one-config collision remains an owner decision and that the two-config sequence must not be represented as a passed gate until approved. The supplied owner **Yes** receipt, completed I1 sequence and complete scoped verdict establish that approval and execution have occurred.

   **Fix:** Update this operative runbook paragraph to describe the approved separate quarterly `2015Q1` and daily `end_quarter=open` configs and link the retained approval and sequence evidence. Historical pending-status passages in earlier receipts can remain as history.


GLOBAL CONSTRAINTS VERBATIM
## Global Constraints

The quoted contract sentences below are copied verbatim from the parent or ADR; numeric settings remain the accepted starting values. Every task includes these constraints.

- “The implementation will live in **`packages/sec-edgar-ingest/`**, with `sec-edgar-ingest` as the distribution and CLI name and `sec_edgar_ingest` as the Python import package.” (ADR Decision.)
- “All application requests to the SEC share one downloader and one request budget. More ETL workers must not mean more SEC traffic.” (Parent R8.)
- “Discovery requests, downloads, retries and reconciliation all count.” (Parent §4.3.)
- “All collectors in the owner's deployment use the same coordination namespace, including backfill and daily runs.” (Parent §4.3.)
- “Lease loss stops new requests. A successor waits for the previous ownership window and bounded in-flight request allowance to expire before issuing requests.” (Parent §4.3.)
- “Daily work gets the next turn ahead of remaining backfill or reconciliation units.” (Parent §4.3.)
- “Discovery writes an immutable source workset. Collection pins one accepted snapshot per member in the manifest, then emits a separate immutable snapshot workset naming exact hashes. Retries complete unresolved members without replacing pinned inputs. ETL never silently follows a mutable “latest”.” (Parent §4.1.)
- “Never advance discovery past a failed directory read.” (Parent §4.2.)
- “Also revisit pending and failed source identities regardless of their quarter.” (Parent §4.2.)
- “Daily discovery starts at the approved handoff date and replays overlap with the baseline.” (Parent §4.2.)
- “A truncated or invalid body is quarantined, never accepted as an empty index.” (Parent §4.3.)
- “Promote a valid download to its content-addressed raw location before marking it downloaded.” (Parent §4.3.)
- “Discovery may exist before a snapshot; failures belong to attempts and do not erase an earlier successful state.” (Parent §4.5.)
- “There is no assumed transaction spanning Blob Storage and Table Storage.” (Parent §4.6.)
- “An HTTP failure, absent listing or open-quarter absence is not a withdrawal.” (Parent R10.)
- “CI runs on committed fixtures and mocked SEC responses; it downloads nothing from the SEC.” (Parent §6.)
- Python >=3.14; intended historical range 2010 Q1 through the open quarter; initial development range 2015 Q1 through the open quarter; resolve and pin the end quarter at each run's start; daily handoff 2026-10-01; SEC User-Agent `Lowell Mason sec-edgar-ingest mason.lowell@mac.com`.
- `sec.requests_per_second`: 3 requests/second, no bursts; `sec.max_active_collectors`: 1 across all application pipelines; `http.max_attempts`: 5 total per request, including the first.
- `http.retry_base_seconds`: 2; `http.retry_cap_seconds`: 120; exponential with jitter, honor longer server delays; `http.connect_timeout_seconds`: 15; `http.read_timeout_seconds`: 60.
- `jobs.replica_retry_limit`: 0; `orchestration.transient_replays`: at most 1 for positively confirmed transient failure; no automatic replay of an ambiguous start. No scheduler/job implementation here.
- Versions are required, explicit and pinned per workset: `etl.parser_version`, `etl.schema_version`, `worker.image_digest`; canonical schema remains `sec-index-v1`. Stage 2 does not implement a parser.
- Accepted acquisition guards, owner answer 2026-10-06: 90 seconds per complete HTTP exchange; 67,108,864 received bytes; 536,870,912 expanded IDX bytes. Guard violations retain evidence and leave unresolved work. No recovery-horizon, format-coverage or capacity claim follows from these values.
- Keep client/download scaffolds on disk but excluded from the workspace and runtime dependency graph. Preserve the four original index-ingest deletions without staging them. Preserve the local/untracked roadmap; never include it incidentally in a commit/PR.
- Accepted F1 remains immutable at SHA-256 `939a724eccf22147015a59d5940ed57f02cc4e9fe9d942a9cd78ae73c34615ff`; accepted evidence manifest is `124e96041548daba8216aa495fc69021751555b0f0e4c890ac85e934f512a131`. Historical pending text is superseded by final acceptance and completion records.
- Quarterly ZIP with one DEFLATE `master.idx` and plain daily IDX are the selected acquisition representations. Bounded specimens are not global format coverage. The 33 uninspected historical daily directories establish no recovery horizon or ingestion coverage.
- Planning and ordinary tests use retained evidence/offline inspection. Stage 1 SEC and temporary compute windows are closed. Fresh live SEC/Azure/compute work needs concrete new authorization and one owner-wide issuer/budget. Delegating code never authorizes network work.
- Do not implement or plan row parsing/normalization, generation publication, reconciliation/withdrawal approval, Azure orchestration/provisioning or scheduled activation. Preserve their parent contracts and stage boundaries.
- Final whole-branch reviewer is explicitly `gpt-6.1-sol`, reasoning effort `max` (GPT-6.1 Max), fresh context and read-only. This owner instruction supersedes generic Opus routing. If unavailable, report the gate as unpassed; do not substitute silently.

